package com.example.macstudent.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    TextView txtDatetime, txtAmount, txtLot, txtSpot, txtCarPlate;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), HomeActivity.class));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);

        txtDatetime = findViewById(R.id.txtDateTime);
        txtDatetime.setText(sp.getString("DateTime", "Data Missing"));

        txtCarPlate = findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(sp.getString("CarPlate","Data Missing"));

        txtLot = findViewById(R.id.txtLot);
        txtLot.setText("Lot " + sp.getString("Lot","Data Missing"));

        txtSpot = findViewById(R.id.txtSpot);
        txtSpot.setText("Spot " + sp.getString("Spot", "Data Missing"));

        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText(String.valueOf(sp.getInt("Amount",0)));

    }
}
